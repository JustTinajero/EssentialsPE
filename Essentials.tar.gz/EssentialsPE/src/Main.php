<?php

declare(strict_types=1);

namespace Tinajero\EssentialsPE;

use pocketmine\plugin\PluginBase;

class Main extends PluginBase{

}
